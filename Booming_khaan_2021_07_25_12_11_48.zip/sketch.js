function draw() {
  ellipse(mouseX, mouseY, 20, 20);
}
function mousePressed() {
  clear();
  background(128);
}